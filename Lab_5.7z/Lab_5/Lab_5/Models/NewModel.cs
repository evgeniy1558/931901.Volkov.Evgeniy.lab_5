﻿using Microsoft.EntityFrameworkCore;


namespace Lab_5.Models
{
    public class NewModel : DbContext
    {
        public DbSet<Hospital> Hospitals { get; set; }
        public DbSet<Lab> Labs { get; set; }
        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Patient> Patients { get; set; }


        public NewModel(DbContextOptions options)
            : base(options)
        {
            Database.EnsureCreated();
        }

        public NewModel()
        {
        }

    }
}